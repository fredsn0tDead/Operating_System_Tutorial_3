#ifndef QUESTIONS_H_
#define QUESTIONS_H_

#include <stdbool.h>
#define MAX_LEN 256

#define NUM_CATEGORIES 3


#define NUM_QUESTIONS 12

static char categories[NUM_CATEGORIES][MAX_LEN] = {

    "Pokemon"
    "Smash Bros"
    "WARZONE"


};

typedef struct {

    char category[MAX_LEN];
    char question[MAX_LEN];
    char answer[MAX_LEN];
    int value;
    bool answered;


}question;

question questions[NUM_QUESTIONS];
//Start the game
extern void start_game(void);
//display question
extern void display_question(char *category, int value);
//check the answers valid
extern bool valid_answer(char *category, int value, char *answer);

//check the answer was answered
extern bool already_answered(char *category, int value);
//check the status of the answer
extern bool answered_status();
// get the question number
extern int get_question_number(char *category, int value);

#endif