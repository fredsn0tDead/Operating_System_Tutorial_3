#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "listofquestions.h"

// Initializes the array of questions for the game
void start_game(void)
{
    // initialize each question struct and assign it to the questions array
    for(int i = 0; i < 12; i++) {
    	strcpy(questions[i].category, categories[i % 3]);
    	questions[i].answered = false;
    	strcpy(questions[i].question, "Question");
    	strcpy(questions[i].answer, "Answer");
    }

    questions[0].value = 200;
    strcpy(questions[0].question, "What game doe Link originate from");
    strcpy(questions[0].answer, "Legend of Zelda");

    questions[1].value = 200;
    strcpy(questions[1].question, "How many characters are in smash ultimate");
    strcpy(questions[1].answer, "89");

    questions[2].value = 200;
    strcpy(questions[2].question, "What is the main region is Pokemon Diamond & Peral");
    strcpy(questions[2].answer, "Sinnoh");

    questions[3].value = 200;
    strcpy(questions[3].question, "Which pokemon is on the cover of pokemon red");
    strcpy(questions[3].answer, "Charizard");

    questions[4].value = 200;
    strcpy(questions[4].question, "What is the name of the pokemon game featuring Kyogre");
    strcpy(questions[4].answer, "Saffire");

    questions[5].value = 200;
    strcpy(questions[5].question, "What is the most popular game mode in Call of duty Warzone");
    strcpy(questions[5].answer, "Battle Royale");

    questions[6].value = 200;
    strcpy(questions[6].question, "What is the name of the round pink character in Smash bros");
    strcpy(questions[6].answer, "Kirby");

    questions[7].value = 200;
    strcpy(questions[7].question, "Is Call of Duty Warzone a fightning game");
    strcpy(questions[7].answer, "No");

    questions[8].value = 200;
    strcpy(questions[8].question, "How many modes are there in Warzone");
    strcpy(questions[8].answer, "6");
}

// Displays each of the remaining categories and question dollar values that have not been answered
void display_categories(void)
{
    // print categories and dollar values for each unanswered question in questions array
    int width = 20;

    for (int i = 0; i < 3; ++i) {
		putchar('+');
		for (int j = 0; j < width; ++j)
			putchar('-');
	}
	printf("+\n");

	for(int i = 0; i < 3; i++) 
		printf("| %-*s", width - 1, categories[i]);
	printf("|\n");

	for (int i = 0; i < 3; ++i) {
		putchar('+');
		for (int j = 0; j < width; ++j)
			putchar('-');
	}

	for(int i = 0; i < 12; i++) {
		if(questions[i].answered == false) {
			printf("| $&-*d", width - 2, questions[i].value);
		} else {
			printf("| %-*s", width - 2, " - ");
		}

		if(i % 3 == 2)
			printf("|\n");
	}

	for (int i = 0; i < 3; ++i) {
		putchar('+');
		for (int j = 0; j < width; ++j)
			putchar('-');
	}
}

// Displays the question for the category and dollar value
void display_question(char *category, int value)
{
	printf("Question (%s for $%d):\n", category, value);

	int num = get_question_number(category, value);
	if(num == -1)
		printf("question %s not found, %d\n", category, value);

	printf("\t%s\n", questions[num].question);
}

// Returns true if the answer is correct for the question for that category and dollar value
bool valid_answer(char *category, int value, char *answer)
{
	int num = get_question_number(category, value);
	if(num == -1)
		printf("question %s not found, %d\n", category, value);

    // Look into string comparison functions
    return (strcasecmp(answer, questions[num].answer) == 0);
}

// Returns true if the question has already been answered
bool already_answered(char *category, int value)
{
	for(int i = 0; i < 12; i++)
		if (questions[i].value == value && strcmp(questions[i].category, category) == 0)
			return questions[i].answered;

    // lookup the question and see if it's already been marked as answered
    return true;
}

void track_answered(char *category, int value) {
	for(int i = 0; i < 12; i++) 
		if(questions[i].value == value && strcmp(questions[i].category, category) == 0)
			questions[i].answered = true;
}

bool answered_status() {
	for(int i = 0; i < 12; i++)
		if(questions[i].answered == false)
			return false;

	return true;
}

int get_question_number(char *category, int value) {
	for(int i = 0; i < 12; i++)
		if(strcmp(questions[i].category, category) == 0 && questions[i].value == value)
			return i;


	return -1;
}

