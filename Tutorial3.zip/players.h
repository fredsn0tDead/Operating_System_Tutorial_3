
//Define some directives
#ifndef PLAYERS_H_
#define PLAYERS_H_
//important a standard library
#include<stdbool.h>

#define MAX_LEN 256


//Create a player type

typedef struct{

    char name[MAX_LEN];
    int score;

} player;


extern bool player_exist(player *player, int numofplayers, char *name);


extern void update_score(player *player, int numofplayers, char *name , int score);




#endif