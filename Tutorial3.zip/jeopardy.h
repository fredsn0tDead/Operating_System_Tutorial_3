//Header file to process the tokenized file



//assign directives #ifdef and defined

#ifndef JEOPARDY_H_
#define JEOPARDY_H_

#define MAX_LEN 256
//External library used for the tokenize
extern void tokenize(char * input, char **tokens);

extern void results(player *players, int num_player);

#endif