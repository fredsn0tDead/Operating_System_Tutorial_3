#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "players.h"


bool player_exists(player *players, int numofplayers, char *name)
{
    for(int i = 0; i < numofplayers; i++){
        if(strcmp(players[i].name, name)==0 )
            return true;

    }
    return false;
}


void update_score(player *players, int numofplayers, char *name, int score)
{
    for(int i = 0; i < numofplayers; i++){
        if(strcmp(players[i].name, name)== 0)
            players[i].score +=score;


    }


}