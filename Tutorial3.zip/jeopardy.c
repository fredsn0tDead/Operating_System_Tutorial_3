#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<stdbool.h>
#include "listofquestions.h"
#include "players.h"
#include "jeopardy.h"

//Define a constant variable with a max of 256 charactets
#define BUFFER_LEN 256

//Define a constant number of players
#define NUM_PLAYERS 4
//Calling the function that will allow us to take the anwsers andconvert them in to a seqeunce of strings
void tokenize(char *x, char **tokens);
//Function to display the results of the game
void results(player *players, int num_player);


int main  (int argc, char*argv[])
{
    player player[NUM_PLAYERS];

    //Starting the game from teh jepoardy.h file
    start_game();

    //print the Jeopardy
    printf("This is Jeopardy \n");


    for(int i =0; i < 4; i++){
        player[i].score = 0;

        printf("Enter player name: ");
        scanf("%s", (char *) &player[i].name);
    }

    //Runs a while loop until the player answer a question
    while(!answered_status())
    {
        system("clear");

        //Chooses a player
        char player_selected[MAX_LEN] = "";
        char category_selected[MAX_LEN] = "";
        int  value = 0;
        //Make sure you can't play with any player that isnt already entered in the system
        while (!player_exists(player, 4, player_selected))
    
         {
            if(strcmp(player_selected, " ") != 0)
                printf("The player %s was not found", player_selected);

                printf("Enter first player's name: ");
                scanf("%s", (char *) &player_selected);
         }

         //After the person anwsers a question need to determine the person entered a correct input
        while(already_answered(category_selected , value));
        {
            if (value !=0)
                printf("Error Wrong Selections");
            //Player enters a category
            printf("Pick a Category: ");
            gethar();
            fget((char *) category_selected, MAX_LEN, stdin);
            strtok(category_selected, "\n");

            printf("Hit Enter: ");
            scanf("%d", (int *) &value);
        }

            system("clear");
            //Call the display question
            display_question(category_selected, value);

            char*answer[MAX_LEN] = {0};
            getchar();
            fgets((char *) answer, MAX_LEN, stdin);
            char *tokenize_anwser;
            if (tokenize_anwser == NULL)
                printf("Oops try again");
            else if(valid_answer(category_selected,value,tokenize_anwser))
            {
                printf("That is the Correct Answer");
                printf("%s gains %d points \n", player_selected, value);
                update_score(player,4,player_selected,value);
            }
            else
            {
                printf("Wrong Anwser");
                int num = get_question_number(category_selected, value);
                printf("The correct anwser was in fact: %s" , questions[num].answer);

            }
            track_answer(category_selected, value);


            }
            results(player, 4);
            getchar();

            return EXIT_SUCCESS;


        }
    //Tokenize function in order to convert the input of characters into a readable anwser
void tokenize(char *input, char **tokens){
    char*str;

    if((str = strtok(input, "")) !=NULL)
        if(strcmp(str, "who") !=0 && strcmp(str,"what") !=0)
            return;
    if((str = strtok(NULL, "")) != NULL)
        if(strcmp(str, "is") !=0)
            return;
    *tokens = strtok(NULL, "\n");


}
//Result function needed to display the number of players
void results(player *players, int num_players) {
    int name = 0;
    int score = 0;
    int winner = 0;

    for(int i = 0; i < num_players; i++) {
        if((int) strlen(players[i].name) > name)
            name = strlen(players[i].name);

        if(players[i].score > score) {
            score = players[i].score;
            winner = i;
        }
    }

    printf("Current Scores: \n");
    for(int i = 0; i < num_players; i++)
        printf("%*s: %d\n", name + 1, players[i].name, players[i].score);

    printf("The Winner is: %s", players[winner].name);
}


   